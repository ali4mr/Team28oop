package Eventsys;

public class Admin extends Person{
    String birthdate;
    Role role;
    int workinghours;
    enum Role{
        OrganizerManager,EventManager,ReportManager
    }


    public Admin(String username,String password,String birthdate,Role role,int workinghours){
        super(username,password);
        this.birthdate=birthdate;
        this.role=role;
        this.workinghours=workinghours;
    }


    @Override
    public String toString() {
        return "Admin{" +
                "password='" + password + '\'' +
                ", username='" + username + '\'' +
                ", workinghours=" + workinghours +
                ", role='" + role + '\'' +
                ", birthdate='" + birthdate + '\'' +
                '}';
    }
}
