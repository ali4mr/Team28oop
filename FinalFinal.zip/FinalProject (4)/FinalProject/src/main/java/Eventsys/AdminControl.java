package Eventsys;

import com.example.finalproject.Main;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.awt.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static Eventsys.Database.categories;

public class AdminControl implements Initializable {
    public AdminControl(){

    }
    @FXML
    private Button LogOut;
    @FXML
    private Button showRooms;
    @FXML
    private Button addRooms;
    @FXML
    private Button viewAttendees;
    @FXML
    private Button viewOrganizers;
    @FXML
    private Button viewEvents;
    @FXML
    private Button addCategories;
    @FXML
    private Button manageCategories;
    @FXML
    private Button createRoom;
    @FXML
    private TextField roomName;
    @FXML
    private TextField roomCapacity;
    @FXML
    private TextField roomHours;
    @FXML
    private TextField categoryname;
    @FXML
    private Button createcategory;
    @FXML
    private ChoiceBox<Category> viewCategories;
    @FXML
    private TextField newCategory;

    public void LogOut() throws IOException {
        Main.changeScene("hello-view.fxml");
    }

    public void showRooms() throws IOException {
    Main.changeScene("viewRooms.fxml");

    }
    public void addRooms() throws IOException {
        Main.changeScene("addRooms.fxml");
    }
    public void viewAttendees() throws IOException {
        Main.changeScene("AdminViewAttendees.fxml");

    }
    public void viewOrganizers() throws IOException{
        Main.changeScene("AdminViewOrganizers.fxml");
    }
    public void viewEvents() throws IOException{
        Main.changeScene("AdminViewEvents.fxml");
    }
    public void addCategories() throws IOException {
        Main.changeScene("addCategories.fxml");
    }
    public void manageCategories() throws IOException {
        Main.changeScene("manageCategories.fxml");
    }
    public void createRoom(){
        String roomname = roomName.getText();
        int capacity = Integer.parseInt(roomCapacity.getText());
        String hours = roomHours.getText();

        Room room = new Room(roomname,capacity);
        Database.availableRooms.add(room);
        room.availableHours.add(hours);
        System.out.println(room.toString());
    }
    public void createCategory(){
        String categoryName= categoryname.getText();
        Category c1 = new Category(categoryName);
        Database.categories.add(c1);
        System.out.println(c1.toString());
    }
        @Override
        public void initialize(URL location, ResourceBundle resources) {
            // Check if the category ChoiceBox is not null
            if (viewCategories != null) {
                if (categories != null && !categories.isEmpty()) {
                    viewCategories.setItems(FXCollections.observableArrayList(categories));
                    System.out.println("Categories populated successfully!");

                    viewCategories.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
                        if (newValue != null) {
                            System.out.println("Selected Category: " + newValue.getName());
                        }
                    });
                } else {
                    System.err.println("The categories list is empty or null!");
                }
            } else {
                System.err.println("Category ChoiceBox is null, please check the FXML and controller connection.");
            }

    }
    public void editCategory(){
        viewCategories.getValue().setName(newCategory.getText());
        for(int i=0;i< categories.size();i++){
            System.out.println(categories.get(i).getName());
        }
    }
    @FXML
    private Button backAdmin;

    public void backAdmin() throws IOException
    {
        Main.changeScene("Admin.fxml");
}
}


