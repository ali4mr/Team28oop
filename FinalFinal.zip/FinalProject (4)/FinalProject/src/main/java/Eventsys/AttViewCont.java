package Eventsys;

import com.example.finalproject.Main;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AttViewCont implements Initializable {

    @FXML
    private ListView<Attendee> attListView;

    @FXML
    private Label myLabel;
    @FXML
    private Button backAdmin;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<Attendee> observableAttendees =
                FXCollections.observableArrayList(Database.attendees);
        attListView.setItems(observableAttendees);
    }

    public void backAdmin() throws IOException
    {
        Main.changeScene("Admin.fxml");
}

}
