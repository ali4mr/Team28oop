package Eventsys;

import javafx.scene.control.ChoiceBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class Attendee extends Person {

    String birthdate;
    String Walletid;
    String address;
    Gender gender;
    Category interests;

    public Attendee(String username, String password, String birthdate, String wallet, String address, Gender gender, Category interests) {
        super(username, password);
        this.birthdate = birthdate;
        this.Walletid = wallet;
        this.address = address;
        this.gender = gender;
        this.interests = interests;
        AttendeeCount++;
    }

    enum Gender{
        Female,Male
    }
    static int AttendeeCount=0;



    public Attendee(){
        super(" "," ");
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getWalletid() {
        return Walletid;
    }

    public void setWalletid(String walletid) {
        this.Walletid = walletid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public int AttendeeCount(){
        return AttendeeCount;
    }

    public String toString() {
        return "Attendee{" +
                "name='" + username + '\'' +
                ", password='" + password + '\'' +
                ", birthDate='" + birthdate + '\'' +
                ", balance='" + Walletid + '\'' +
                ", location='" + address + '\'' +
                ", gender=" + gender +
                ", interests='" + interests + '\'' +
                '}';
    }



}
