package Eventsys;

import com.example.finalproject.Main;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static Eventsys.Database.*;

public class AttendeeControl implements Initializable {
    public AttendeeControl() {
    }

    double totalPrice;

    @FXML
    private ChoiceBox<Event> Eventname;
    @FXML
    private ChoiceBox<Integer> ticketamount;
    @FXML
    private Button Submit;
    @FXML
    private Label price;
    @FXML
    private Label paymentstatus;
    @FXML
    private TextField walletpay;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        if (ticketamount != null) {
            ticketamount.setItems(FXCollections.observableArrayList(1, 2, 3, 4, 5, 6));
            ticketamount.setValue(1);
        }

        if (Eventname != null) {
            Eventname.setItems(FXCollections.observableArrayList(Database.eventsOrganizing));
            Eventname.setValue(Database.eventsOrganizing.get(0));
        }

        if (Eventname != null) {
            Eventname.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
                if (ticketamount != null) {
                    updateprice(newValue, ticketamount.getValue());
                }
            });
        }

        if (ticketamount != null) {
            ticketamount.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
                if (Eventname.getValue() != null) {
                    updateprice(Eventname.getValue(), newValue);
                }
            });
        }

        if (price != null && Eventname.getValue() != null) {
            updateprice(Eventname.getValue(), ticketamount.getValue());
        }
    }

    public void updateprice(Event event, int ticketCount) {
        if (event != null) {
            totalPrice = event.getPrice() * ticketCount;
            price.setText("$" + totalPrice);
        }
    }

    public void submitReciept() {
        String walletId = (walletpay != null && walletpay.getText() != null) ? walletpay.getText() : "";
        boolean walletFound = false;

        if (Wallets != null) {
            for (int i = 0; i < Wallets.size(); i++) {
                if (walletId.equals(Wallets.get(i).id)) {
                    walletFound = true;

                    if (totalPrice > 0) {
                        if (Wallets.get(i).balance >= totalPrice) {
                            if (paymentstatus != null) {
                                paymentstatus.setText("Payment Successful");
                            }
                        } else {
                            if (paymentstatus != null) {
                                paymentstatus.setText("Insufficient Balance");
                            }
                        }
                    } else {
                        if (paymentstatus != null) {
                            paymentstatus.setText("Invalid total price");
                        }
                    }
                    break;
                }
            }
        }

        if (!walletFound) {
            if (paymentstatus != null) {
                paymentstatus.setText("Wallet not found");
            }
        }
    }

    public void LogOut() throws IOException{
        Main.changeScene("hello-view.fxml");
    }
}
