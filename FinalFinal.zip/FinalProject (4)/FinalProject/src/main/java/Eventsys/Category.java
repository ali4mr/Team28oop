package Eventsys;

public class Category {
    private String name;

    public Category(String name) {  // Constructor
        this.name = name;
    }

    public void setName(String newName) {
        this.name = newName;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;  // This ensures that the name of the category is displayed in the ChoiceBox
    }
}
