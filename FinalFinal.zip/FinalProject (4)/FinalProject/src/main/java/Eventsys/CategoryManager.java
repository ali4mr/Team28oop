package Eventsys;
import java.util.ArrayList;

public class CategoryManager {
    private ArrayList<Category> categories;

    public CategoryManager() {
        categories = new ArrayList<>();
    }


    public void viewCategories() {
        System.out.println("Categories:");
        for (Category category : categories) {
            System.out.println("- " + category.getName());
        }
    }



    @Override
    public String toString() {
        return "CategoryManager{" +
                "categories=" + categories +
                '}';
    }
}
