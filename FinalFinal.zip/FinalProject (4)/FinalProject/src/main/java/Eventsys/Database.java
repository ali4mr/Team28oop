package Eventsys;
import java.util.ArrayList;

public class Database {
    public static ArrayList<Attendee> attendees = new ArrayList<>();
    public static ArrayList<Room> availableRooms = new ArrayList<>();
    public static ArrayList<Event> eventsOrganizing = new ArrayList<>();
    public static ArrayList<Organizer> organizers = new ArrayList<>();
    public static ArrayList<Admin> admins = new ArrayList<>();
    public static ArrayList<Wallet> Wallets = new ArrayList<>();
    public static  ArrayList<Category> categories= new ArrayList();

    public void showAllRooms() {
        for (int i = 0; i < availableRooms.size(); i++) {
            Room room = availableRooms.get(i);
            System.out.println(room.name + " (Capacity: " + room.capacity + ")");
            room.showAvailableHours();
        }
    }
    public void showAvailableRooms() {
        System.out.println("Available Rooms:");
        for (Room room : availableRooms) {
            System.out.println("- " + room);
        }
    }

    public void showEvents() {
        System.out.println("Events Being Organized:");
        for (Event event : eventsOrganizing) {
            System.out.println("- " + event);
        }
    }

    public void showAttendees() {
        System.out.println("Attendees:");
        for (Attendee a : attendees) {
            System.out.println("- " + a.username + " | Gender: " + a.gender + " | Interests: " + a.interests);
        }
    }

    public void showOrganizers() {
        System.out.println("Organizers:");
        for (Organizer o : organizers) {
            System.out.println("- " + o.username);
        }
    }

    static {
        categories.add(new Category("Sports"));
        categories.add(new Category("Music"));
        categories.add(new Category("Festivals"));
        categories.add(new Category("Gaming"));
        categories.add(new Category("Charity"));
        // Attendees
        attendees.add(new Attendee("Mohamed", "password123", "15/05/1995", "1000.50", "Cairo, Egypt", Attendee.Gender.Male, categories.get(0)));  // Sports
        attendees.add(new Attendee("Mariam", "password456", "22/03/1990", "1200.75", "Alexandria, Egypt", Attendee.Gender.Female, categories.get(1)));  // Music
        attendees.add(new Attendee("Ahmed", "password789", "10/08/2000", "1500.00", "Giza, Egypt", Attendee.Gender.Male, categories.get(2)));  // Festivals
        attendees.add(new Attendee("Lara", "password321", "18/11/1993", "1100.25", "Luxor, Egypt", Attendee.Gender.Female, categories.get(3)));  // Gaming
        attendees.add(new Attendee("Tamer", "password654", "05/01/1992", "1300.60", "Sharm El Sheikh, Egypt", Attendee.Gender.Male, categories.get(4)));  // Charity

        // Organizers
        Organizer o1 = new Organizer("Ahmed Tamer Goat", "Juffair123");
        Organizer o2 = new Organizer("Ali Amr", "Ali123");
        Organizer o3 = new Organizer("Aley Derbala", "Derbala123");

        organizers.add(o1);
        organizers.add(o2);
        organizers.add(o3);

        // Admins
        Admin a1= new Admin("Aley Abdelkader", "Aley123", "1/1/1999", Admin.Role.OrganizerManager, 7);
        Admin a2= new Admin("Marwan Khattab", "Marwan123", "1/9/1999", Admin.Role.OrganizerManager, 7);
        admins.add(a1);
        admins.add(a2);

        // Events
        Event e1 = new Event("Padel Tournamet", "01/6/2025", "Qatar", "Sports", 450, 1);
        Event e2 = new Event("Nile Sound Festival", "10/7/2025", "Cairo", "Music", 120, 2);
        Event e3 = new Event("Fortnite Tournamet", "03/8/2025", "Australia", "Gaming", 60, 3);
        Event e4 = new Event("Mediterranean Charity Gala", "15/6/2025", "Athens", "Charity", 200, 4);
        Event e5 = new Event("Cairo Music Nights", "12/6/2025", "Cairo", "Music", 90, 5);
        Event e6 = new Event("Safari Ride", "20/9/2025", "Dubai", "Sports", 300, 6);
        Event e7 = new Event("Fifa Tournament", "18/5/2025", "Riyadh", "Gaming", 75, 7);
        Event e8 = new Event("Hope Run for Children", "25/4/2025", "Cape Town", "Charity", 50, 8);
        Event e9 = new Event("Sunset Dance Festival", "29/6/2025", "Ibiza", "Festivals", 150, 9);
        Event e10 = new Event("5 aside Tournament", "05/5/2025", "Cairo", "Sports", 100, 10);

        eventsOrganizing.add(e1);
        eventsOrganizing.add(e2);
        eventsOrganizing.add(e3);
        eventsOrganizing.add(e4);
        eventsOrganizing.add(e5);
        eventsOrganizing.add(e6);
        eventsOrganizing.add(e7);
        eventsOrganizing.add(e8);
        eventsOrganizing.add(e9);
        eventsOrganizing.add(e10);


        ;

        // Rooms
        Room r1 = new Room("Room1", 1000);
        availableRooms.add(r1);
        r1.addAvailableHour("9:00 AM - 10:00 AM");
        r1.addAvailableHour("10:00 AM - 11:00 AM");
        r1.addAvailableHour("11:00 AM - 12:00 PM");

        Room r2 = new Room("Room2", 2000);
        availableRooms.add(r2);
        r2.addAvailableHour("9:00 AM - 10:00 AM");
        r2.addAvailableHour("10:00 AM - 11:00 AM");
        r2.addAvailableHour("11:00 AM - 12:00 PM");

        Room r3 = new Room("Room3", 3000);
        availableRooms.add(r3);
        r3.addAvailableHour("9:00 AM - 10:00 AM");
        r3.addAvailableHour("10:00 AM - 11:00 AM");
        r3.addAvailableHour("11:00 AM - 12:00 PM");

        Room r4 = new Room("Room4", 4000);
        availableRooms.add(r4);
        r4.addAvailableHour("9:00 AM - 10:00 AM");
        r4.addAvailableHour("10:00 AM - 11:00 AM");
        r4.addAvailableHour("11:00 AM - 12:00 PM");

        Room r5 = new Room("Room5", 5000);
        availableRooms.add(r5);
        r5.addAvailableHour("9:00 AM - 10:00 AM");
        r5.addAvailableHour("10:00 AM - 11:00 AM");
        r5.addAvailableHour("11:00 AM - 12:00 PM");

        Room r6 = new Room("Room6", 100);
        availableRooms.add(r6);
        r6.addAvailableHour("9:00 AM - 10:00 AM");
        r6.addAvailableHour("10:00 AM - 11:00 AM");
        r6.addAvailableHour("11:00 AM - 12:00 PM");

        Room r7 = new Room("Room7", 200);
        availableRooms.add(r7);
        r7.addAvailableHour("9:00 AM - 10:00 AM");
        r7.addAvailableHour("10:00 AM - 11:00 AM");
        r7.addAvailableHour("11:00 AM - 12:00 PM");

        Room r8 = new Room("Room8", 300);
        availableRooms.add(r8);
        r8.addAvailableHour("9:00 AM - 10:00 AM");
        r8.addAvailableHour("10:00 AM - 11:00 AM");
        r8.addAvailableHour("11:00 AM - 12:00 PM");

        Room r9 = new Room("Room9", 400);
        availableRooms.add(r9);
        r9.addAvailableHour("9:00 AM - 10:00 AM");
        r9.addAvailableHour("10:00 AM - 11:00 AM");
        r9.addAvailableHour("11:00 AM - 12:00 PM");

        Room r10 = new Room("Room10", 500);
        availableRooms.add(r10);
        r10.addAvailableHour("9:00 AM - 10:00 AM");
        r10.addAvailableHour("10:00 AM - 11:00 AM");
        r10.addAvailableHour("11:00 AM - 1:00 PM");

        Wallet wallet1 = new Wallet("A001", 50000);
        Wallet wallet2 = new Wallet("A002", 2000.75);
        Wallet wallet3 = new Wallet("A003", 1500.30);
        Wallet wallet4 = new Wallet("A004", 3000.00);
        Wallet wallet5 = new Wallet("A005", 2500.10);
        Wallet wallet6 = new Wallet("A006", 1750.45);
        Wallet wallet7 = new Wallet("A007", 2200.00);
        Wallet wallet8 = new Wallet("A008", 2800.60);
        Wallet wallet9 = new Wallet("A009", 1350.25);
        Wallet wallet10 = new Wallet("A010", 5000.00);

        Wallets.add(wallet1);
        Wallets.add(wallet2);
        Wallets.add(wallet3);
        Wallets.add(wallet4);
        Wallets.add(wallet5);
        Wallets.add(wallet6);
        Wallets.add(wallet7);
        Wallets.add(wallet8);
        Wallets.add(wallet9);
        Wallets.add(wallet10);




    }
}
