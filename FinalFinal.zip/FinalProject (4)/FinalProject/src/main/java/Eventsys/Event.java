package Eventsys;

import javafx.scene.control.ChoiceBox;

import java.awt.*;

public class Event {

    String name;
    String date;
    String location;
    String category;
    double price;
    int EventID;

    public Event(String name, String date, String location, String category, double price,int EventID) {
        this.name = name;
        this.date = date;
        this.location = location;
        this.category = category;
        this.price = price;
        this.EventID=EventID;
    }



    public Event(String name, String date, String location, String category, String price, String id) {
        this.name = name;
        this.date = date;
        this.location = location;
        this.category = category;
        this.price = Double.parseDouble(price);
        this.EventID = Integer.parseInt(id);
    }

    public int getEventID() {
        return EventID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setEventID(int eventID) {
        EventID = eventID;
    }

    @Override
    public String toString() {
        return name +" ("+ location + " )";
    }
}
