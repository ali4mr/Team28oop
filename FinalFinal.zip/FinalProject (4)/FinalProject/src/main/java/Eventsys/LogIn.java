package Eventsys;

import com.example.finalproject.Main;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;

import java.io.IOException;

public class LogIn {
    public LogIn() {}

    public static boolean orgcheck = false;
    public static boolean admincheck = false;
    public static boolean attcheck = false;

    @FXML
    private Button button;
    public Button signup;
    @FXML
    private Label wrongLogIn;
    @FXML
    private TextField username;
    private TextField wallet;
    @FXML
    private PasswordField password;

    public void userLogIn(ActionEvent event) throws IOException {
        checkLogin();
    }

    private void checkLogin() throws IOException {
        // Reset flags before each login attempt
        orgcheck = false;
        admincheck = false;
        attcheck = false;

        // Admin check
        for (int a = 0; a < Database.admins.size(); a++) {
            if (username.getText().equals(Database.admins.get(a).username) &&
                    password.getText().equals(Database.admins.get(a).password)) {
                admincheck = true;
                break;
            }
        }

        // Organizer check
        for (int a = 0; a < Database.organizers.size(); a++) {
            if (username.getText().equals(Database.organizers.get(a).username) &&
                    password.getText().equals(Database.organizers.get(a).password)) {
                orgcheck = true;
                break;
            }
        }

        // Attendee check
        for (int a = 0; a < Database.attendees.size(); a++) {
            if (username.getText().equals(Database.attendees.get(a).username) &&
                    password.getText().equals(Database.attendees.get(a).password)) {
                attcheck = true;
                break;
            }
        }

        // Navigation based on role (Admin gets priority)
        if (admincheck) {
            Main.changeScene("Admin.fxml");
        } else if (orgcheck) {
            Main.changeScene("Organizer.fxml");
        } else if (attcheck) {
            Main.changeScene("Attendee2.fxml");
        } else {
            wrongLogIn.setText("Invalid Details");
        }
    }

    public void SignUp() throws IOException {
        Main.changeScene("SignUp.fxml");
    }
}
