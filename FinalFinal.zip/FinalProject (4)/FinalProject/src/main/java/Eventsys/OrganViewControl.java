package Eventsys;

import com.example.finalproject.Main;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class OrganViewControl implements Initializable {

    @FXML
    private ListView<Organizer> organizerListView;

    @FXML
    private Label myLabel;
    @FXML
    private Button backAdmin;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ObservableList<Organizer> observableOrganizer =
                FXCollections.observableArrayList(Database.organizers);
        organizerListView.setItems(observableOrganizer);
    }

    public void backAdmin() throws IOException
    {
        Main.changeScene("Admin.fxml");
}
}