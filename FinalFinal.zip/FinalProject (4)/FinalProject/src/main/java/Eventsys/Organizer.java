package Eventsys;
import java.util.ArrayList;

public class Organizer extends Person {
    public static ArrayList<Room> availableRooms = new ArrayList<>();
    public static ArrayList<Event> eventsOrganizing = new ArrayList<>();
    public static ArrayList<Attendee> attendees = new ArrayList<>();
    public static ArrayList<Organizer> organizers = new ArrayList<>();


    public Organizer(String username, String password) {
        super(username, password);
    }

    public Organizer() {
    }

    public void showAvailableRooms() {
        System.out.println("Available Rooms:");
        for (Room room : availableRooms) {
            System.out.println("- " + room);
        }
    }

    public void showEvents() {
        System.out.println("Events Being Organized:");
        for (Event event : eventsOrganizing) {
            System.out.println("- " + event);
        }
    }

    public void showAttendees() {
        System.out.println("Attendees:");
        for (Attendee a : attendees) {
            System.out.println("- " + a.username + " | Gender: " + a.gender + " | Interests: " + a.interests);
        }
    }

    public void showOrganizers() {
        System.out.println("Organizers:");
        for (Organizer o : organizers) {
            System.out.println("- " + o.username);
        }
    }

    public void showAllRooms() {
        for (int i = 0; i < availableRooms.size(); i++) {
            Room room = availableRooms.get(i);
            System.out.println(room.name + " (Capacity: " + room.capacity + ")");
            room.showAvailableHours();
        }
    }
    @Override
    public String toString() {
        return
                "username='" + username + '\'' +
                        ", password='" + password;
    }
}
