package Eventsys;

import com.example.finalproject.Main;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import javafx.util.Callback;
import javax.swing.event.ChangeListener;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static Eventsys.Database.availableRooms;
import static Eventsys.Database.categories;

public class OrganizerControl implements Initializable {

    @FXML
    private Button createEvent;
    @FXML
    private Button rentRoom;
    @FXML
    private TextField eventname;
    @FXML
    private TextField eventdate;
    @FXML
    private TextField eventlocation;
    @FXML
    private TextField eventid;
    @FXML
    private TextField ticketprice;
    @FXML
    private ChoiceBox<Category> category;
    @FXML
    private Label EventStatus;
    @FXML
    private ComboBox<Room> rooms;
    @FXML
    private Button rent;
    @FXML
    private ComboBox<String> hours;
    @FXML
    private Label rentStatus;
    @FXML
    private Button backOrganizer;
    private Button LogOut;

    public void createEvents() throws IOException {
        Main.changeScene("createEvent.fxml");
    }

    public void rentRooms() throws IOException {
        Main.changeScene("rentRoom.fxml");
    }

    public void create() {
        try {
            String name = eventname.getText();
            String date = eventdate.getText();
            String location = eventlocation.getText();
            String categoryName = category.getValue() != null ? category.getValue().getName() : "Uncategorized";
            String priceText = ticketprice.getText();
            String idText = eventid.getText();

            System.out.println("Input Check -> Name: " + name + ", Date: " + date + ", Location: " + location + ", Category: " + categoryName + ", Price: " + priceText + ", ID: " + idText);

            Event event = new Event(name, date, location, categoryName, priceText, idText);
            Database.eventsOrganizing.add(event);
            EventStatus.setText("Event Created Successfully");
            System.out.println(event.toString());
        } catch (Exception e) {
            EventStatus.setText("Error creating event: " + e.getMessage());
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        if (category != null) {
            if (categories != null && !categories.isEmpty()) {
                category.setItems(FXCollections.observableArrayList(categories));
                System.out.println("Categories populated successfully!");

                category.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
                    if (newValue != null) {
                        System.out.println("Selected Category: " + newValue.getName());
                    }
                });
            } else {
                System.err.println("The categories list is empty or null!");
            }
        } else {
            System.err.println("Category ChoiceBox is null, please check the FXML and controller connection.");
        }

        if (rooms != null) {
            populateRoomsComboBox(rooms);

            rooms.getSelectionModel().selectedItemProperty().addListener((obs, oldRoom, newRoom) -> {
                if (newRoom != null && hours != null) {
                    populateHoursComboBox(hours);
                }
            });
        } else {
            System.err.println("Rooms ComboBox is null, please check the FXML and controller connection.");
        }

        if (hours != null) {
            hours.setPromptText("Select available hour");
        }
    }

    public static void populateRoomsComboBox(ComboBox<Room> roomsComboBox) {
        roomsComboBox.getItems().clear();
        roomsComboBox.getItems().addAll(Database.availableRooms);

        roomsComboBox.setCellFactory(new Callback<ListView<Room>, ListCell<Room>>() {
            @Override
            public ListCell<Room> call(ListView<Room> listView) {
                return new ListCell<Room>() {
                    @Override
                    protected void updateItem(Room room, boolean empty) {
                        super.updateItem(room, empty);
                        if (empty || room == null) {
                            setText(null);
                        } else {
                            setText(room.getName() + " (Capacity: " + room.getCapacity() + ")");
                        }
                    }
                };
            }
        });

        roomsComboBox.setButtonCell(new ListCell<Room>() {
            @Override
            protected void updateItem(Room room, boolean empty) {
                super.updateItem(room, empty);
                if (empty || room == null) {
                    setText(null);
                } else {
                    setText(room.getName() + " (Capacity: " + room.getCapacity() + ")");
                }
            }
        });

        roomsComboBox.setPromptText("Select a room");
    }

    public void populateHoursComboBox(ComboBox<String> hours) {
        hours.getItems().clear();

        Room selectedRoom = rooms.getValue();
        if (selectedRoom != null && selectedRoom.availableHours != null) {
            hours.getItems().addAll(selectedRoom.availableHours);
        } else {
            System.err.println("No room selected or no available hours.");
        }
    }

    public void continueRent() {
        Room selectedRoom = rooms.getValue();
        String selectedHour = hours.getValue();

        if (selectedRoom != null && selectedHour != null) {
            selectedRoom.availableHours.remove(selectedHour);
            populateHoursComboBox(hours);
            rentStatus.setText("Room Rented Succesfully");
        } else {
            System.err.println("Please select both a room and an hour before continuing.");
        }
    }

    @FXML
    private void LogOut() throws IOException {
        Main.changeScene("hello-view.fxml");
    }
    @FXML
    private void backOrganizer() throws IOException {
        Main.changeScene("Organizer.fxml");
    }

}