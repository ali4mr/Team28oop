
package Eventsys;
import java.util.ArrayList;
public class Room {
    String name;
    int capacity;
    ArrayList<String> availableHours;

    public Room(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.availableHours = new ArrayList<>();
    }
    public void addAvailableHour(String timeSlot) {
        availableHours.add(timeSlot);
    }

    public void showAvailableHours() {
        System.out.println("Available hours for " + name + ":");
        for (String hour : availableHours) {
            System.out.println("- " + hour);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public ArrayList<String> getAvailableHours() {
        return availableHours;
    }

    public void setAvailableHours(ArrayList<String> availableHours) {
        this.availableHours = availableHours;
    }

    @Override
    public String toString() {
        return name + " (Capacity: " + capacity + ")";
    }
}
