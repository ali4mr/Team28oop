package Eventsys;
import com.example.finalproject.Main;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


import static Eventsys.Database.categories;
public class SignUp implements Initializable {
    public SignUp(){

    }
    @FXML
    private TextField user;
    @FXML
    private TextField birthdate;
    @FXML
    private ChoiceBox<Category> interests;
    @FXML
    private TextField address;
    @FXML
    private TextField wallet;
    @FXML
    private PasswordField pass;
    @FXML
    private ChoiceBox<Attendee.Gender> genderChoice;
    @FXML
    private Button backSignup;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        if (genderChoice != null) {
            genderChoice.setItems(FXCollections.observableArrayList(Attendee.Gender.values()));
            genderChoice.setValue(Attendee.Gender.Male);
        } else {
            System.err.println("genderChoice is null!");
        }

        if (interests != null) {
            if (categories != null && !categories.isEmpty()) {
                interests.setItems(FXCollections.observableArrayList(categories));
                System.out.println("Categories populated successfully!");

                interests.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
                    if (newValue != null) {
                        System.out.println("Selected Category: " + newValue.getName());
                    }
                });
            } else {
                System.out.println("List is empty");
            }
        } else {
            System.out.println("Category ChoiceBox is null, please check the FXML and controller connection.");
        }
    }

    public void Create() throws IOException {
        String username = user.getText();
        String password = pass.getText();
        String birth = birthdate.getText();
        String walletAmount = wallet.getText();
        String addr = address.getText();
        Attendee.Gender gender = genderChoice.getValue();
        Category interest = interests.getValue();

        Attendee newAtt = new Attendee(username, password, birth, walletAmount, addr, gender, interest);
        Database.attendees.add(newAtt);
        System.out.println(newAtt);
        Main.changeScene("hello-view.fxml");
    }
    @FXML
    private void backSignup() throws IOException {
        Main.changeScene("hello-view.fxml");
    }
}