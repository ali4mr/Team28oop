package Eventsys;

import java.util.ArrayList;

public class Wallet {
    String id;
    double balance;

    public Wallet(String id,double balance){
        this.id = id;
        this.balance=balance;
    }

    public double getBalance() {
        return balance;
    }

    public boolean hasSufficientFunds(double amount) {
        return balance >= amount;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    public void deduct(double amount) {
        if (amount <= 0) {
            System.out.println("Deduction amount must be positive.");
        } else if (!hasSufficientFunds(amount)) {
            System.out.println("Insufficient Walletid.");
        } else {
            balance -= amount;
        }
    }
}