module com.example.finalproject {
    requires javafx.controls;
    requires javafx.fxml;
    requires jdk.jdi;
    requires java.desktop;

    opens Eventsys to javafx.fxml;
    exports com.example.finalproject;
}
